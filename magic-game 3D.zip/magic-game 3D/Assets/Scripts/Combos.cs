﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Combos : MonoBehaviour {
    Status status;
    void Start()
    {
        status = GetComponent<Status>();
    }

   
}
