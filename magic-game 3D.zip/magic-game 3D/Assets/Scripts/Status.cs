﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Status : MonoBehaviour {

    public float HP = 100, HPMAX;
    [Space(8)] public float MP; public float MPMAX;
    [Space(8)] public float XP; public float XPMAX;
    [Space(8)] public float energy;public float MaxEnergy;

    
}
